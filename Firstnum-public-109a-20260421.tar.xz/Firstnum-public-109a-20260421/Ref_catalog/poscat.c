/* poscat */
/* Version: 0.1-20260105 */
/* Licenza GPLv3 */ 
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <float.h>
#define APPEND "a"
#define NPR   2UL
#define NDIVS 0UL
#define NFILE "tabprime_4294967296.txt"
int main(int argc, char **argv) {
  unsigned long primenum(unsigned long);
  unsigned long number=1UL,limit=1UL,limax=3UL,pcount=0UL,ppos=0UL;
  unsigned long delta=100000UL,partial=0UL,lopart=1UL,hipart=+delta;
  char nfile[128],*pnf;
  FILE *fp;
  pnf=nfile;
  if(argc==1||argc>2) {
    printf("Errore! È richiesto un solo parametro:\n");
    return(printf("        l'estremo superiore di una serie.\n\n"));
  }
  else {
    if(**(argv+1)=='?'||**(argv+1)=='h') {
      printf("Leggenda dei parametri generati:\n");
      printf(" Esempio: 15 1500001 (114155)\n");
      printf(" 15 = Posizione progressiva nella serie.\n");
      printf(" 1500001 = Valore incrementato nella serie numerica.\n");
      printf(" (114155) = Posizione cardinale dell'ultimo numero\n");
      return(printf("  primo precedente al valore progressivo indicato.\n\n"));
    }
    else {
      if(isalpha(**(argv+1))||ispunct(**(argv+1)))
        return(printf("Errore! Parametro non conforme.\n\n"));
    } 
    limax=(unsigned long)atof(*(argv+1));
    if(limax<=delta*2)
      return(printf("Errore! Valore troppo basso, è richiesto >%lu.\n\n",delta*2));
    pnf=NFILE;
    if((fp=fopen(pnf,APPEND))==NULL)
      printf("Errore! non si può aprire il file.\n\n");
    if(limax>=1000000)
      printf("Attendere, elaborazione in corso...\n");
    for(;lopart<hipart;) {
      if(hipart>=limax) {
        fclose(fp);
        if(limax>=1000000)
          return(printf("Fine elaborazione.\n\n"));
        else
          return(putchar('\n'));
      }
      number=lopart;
      limit=hipart;
      pcount=0;
      for(;number<limit;number+=2) {
        if((primenum(number))==NPR)
          pcount++;
      }
      partial+=pcount;
      ppos++;
      printf("%lu %lu (%lu)\n",ppos,number,partial);
      fprintf(fp,"%lu %lu (%lu)\n",ppos,number,partial);
      lopart+=delta;
      hipart=lopart+delta;
    }
  }
}
/* funzione che discrimina numeri primi da numeri divisibili */
unsigned long primenum(unsigned long number) {
  unsigned long nbase=0UL,ndivs=2UL,divsf=0UL;  
  if(number==2)
    return NPR;    /* Il due è considerato numero primo². */
  nbase=(unsigned long)sqrt((double)number);
  nbase++;
  while(nbase>=ndivs) {
    if(!(number%ndivs))
      divsf=ndivs,ndivs=nbase;
    ndivs++;
  }
  if(!divsf)
    return NPR;
  else
    return NDIVS;
}

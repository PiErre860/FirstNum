/* prmcat */
/* Version: 0.1-20260313 */
/* Licenza GPLv3 */ 
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <float.h>
#define APPEND "a"
#define NPR   2UL
#define NDIVS 0UL
#define NFILE "tabcount_203280221.txt"
int main(int argc, char **argv) {
  unsigned long primenum(unsigned long);
  unsigned long number=1UL,ppos=1UL;
  unsigned long delta=10000UL;
  unsigned long prmpos=0,hippos=0,prmcnt=0;
  char nfile[128],*pnf;
  FILE *fp;
  pnf=nfile;
  if(argc==1||argc>2) {
    printf("Errore! È richiesto un solo parametro:\n");
    return(printf("        l'estremo superiore di una serie.\n\n"));
  }
  else {
    if(**(argv+1)=='?'||**(argv+1)=='h') {
      printf("Leggenda dei parametri generati:\n");
      printf(" Esempio: 15 2015177 (150000)\n");
      printf(" 15 = Posizione progressiva nella serie.\n");
      printf(" 2015177 = Valore incrementato nella serie numerica.\n");
      printf(" (150000) = Posizione cardinale dell'ultimo numero\n");
      return(printf("  primo precedente al valore progressivo indicato.\n\n"));
    }
    else {
      if(isalpha(**(argv+1))||ispunct(**(argv+1)))
        return(printf("Errore! Parametro non conforme.\n\n"));
    } 
    hippos=(unsigned long)atof(*(argv+1));
    if(hippos<delta)
      return(printf("Errore! Valore troppo basso, è richiesto >%lu.\n\n",delta));
    pnf=NFILE;
    if((fp=fopen(pnf,APPEND))==NULL)
      printf("Errore! non si può aprire il file.\n\n");
    if(prmpos>=10000)
      printf("Attendere, elaborazione in corso...\n");
    number=104729;   /* Numero primo iniziale in posizione 10000. */
    prmcnt=10000;   /* Posizione del primo numero primo della serie. */
    /* Calcolo e stampa di un numero primo ogni 10000 posizioni. */
    /* Su ogi riga viene stampato il numero sequenziale di linea, - */
    /* il numero primo e la sua corrispondente posizione cardinale. */
    while(prmcnt<hippos) {
      prmpos+=delta;
      for(;prmcnt<prmpos;prmcnt++) {
        number++;
        while((primenum(number))!=NPR) number++;
      }
      printf("%lu %lu (%lu)\n",ppos,number,prmcnt); 
      fprintf(fp,"%lu %lu (%lu)\n",ppos,number,prmcnt);
      ppos++;
    }
    fclose(fp);
  }
}
/* Funzione che discrimina numeri primi da numeri divisibili */
unsigned long primenum(unsigned long number) {
  unsigned long nbase=0UL,ndivs=2UL,divsf=0UL;  
  if(number==2)
    return NPR;    /* Il due è considerato numero primo. */
  nbase=(unsigned long)sqrt((double)number);
  nbase++;
  while(nbase>=ndivs) {
    if(!(number%ndivs))
      divsf=ndivs,ndivs=nbase;
    ndivs++;
  }
  if(!divsf)
    return NPR;
  else
    return NDIVS;
}

